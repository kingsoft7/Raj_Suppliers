<script type="text/javascript" src="<?= base_url('assets/js/jquery-1.11.1.js')?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js')?>"></script>
</body>
</html>